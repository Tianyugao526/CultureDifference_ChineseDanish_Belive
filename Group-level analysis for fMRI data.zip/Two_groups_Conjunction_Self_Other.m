%-----------------------------------------------------------------------
% Job saved on 03-Nov-2020 22:14:21 by cfg_util (rev $Rev: 6134 $)
% spm SPM - SPM12 (6225)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.stats.factorial_design.dir = {'E:\CSCN\Believe_fmri_Danish&China\Believe_Danish&China\Image\Contrast\05_self_other_conjunction'};
%%
matlabbatch{1}.spm.stats.factorial_design.des.anova.icell(1).scans = {
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub01_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub02_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub03_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub04_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub05_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub06_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub07_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub08_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub09_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub10_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub11_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub12_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub13_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub14_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub15_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub16_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub17_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub18_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub19_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub20_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub21_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub22_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub23_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub24_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub25_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub26_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub27_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub28_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub29_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub30_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub31_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub32_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub33_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub34_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub35_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_Danish\con05_Self_Other\sub36_con_0005.img,1'
                                                           };
%%
%%
matlabbatch{1}.spm.stats.factorial_design.des.anova.icell(2).scans = {
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub01_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub02_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub03_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub04_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub05_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub06_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub07_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub08_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub09_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub11_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub12_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub13_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub14_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub15_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub16_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub17_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub18_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub19_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub20_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub21_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub22_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub23_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub24_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub25_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub26_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub27_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub28_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub29_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub30_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub31_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub32_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub33_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub34_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub35_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub36_con_0005.img,1'
                                                           'E:\CSCN\Believe_fmri_Danish&China\GLM\GroupResult_except_sub10\con05_Self_Other\sub37_con_0005.img,1'
                                                           };
%%
matlabbatch{1}.spm.stats.factorial_design.des.anova.dept = 0;
matlabbatch{1}.spm.stats.factorial_design.des.anova.variance = 1;
matlabbatch{1}.spm.stats.factorial_design.des.anova.gmsca = 0;
matlabbatch{1}.spm.stats.factorial_design.des.anova.ancova = 0;
matlabbatch{1}.spm.stats.factorial_design.cov = struct('c', {}, 'cname', {}, 'iCFI', {}, 'iCC', {});
matlabbatch{1}.spm.stats.factorial_design.multi_cov = struct('files', {}, 'iCFI', {}, 'iCC', {});
matlabbatch{1}.spm.stats.factorial_design.masking.tm.tm_none = 1;
matlabbatch{1}.spm.stats.factorial_design.masking.im = 1;
matlabbatch{1}.spm.stats.factorial_design.masking.em = {''};
matlabbatch{1}.spm.stats.factorial_design.globalc.g_omit = 1;
matlabbatch{1}.spm.stats.factorial_design.globalm.gmsca.gmsca_no = 1;
matlabbatch{1}.spm.stats.factorial_design.globalm.glonorm = 1;
matlabbatch{2}.spm.stats.fmri_est.spmmat(1) = cfg_dep('Factorial design specification: SPM.mat File', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{2}.spm.stats.fmri_est.write_residuals = 0;
matlabbatch{2}.spm.stats.fmri_est.method.Classical = 1;
matlabbatch{3}.spm.stats.con.spmmat(1) = cfg_dep('Model estimation: SPM.mat File', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{3}.spm.stats.con.consess{1}.fcon.name = 'Danish';
matlabbatch{3}.spm.stats.con.consess{1}.fcon.weights = [1 0];
matlabbatch{3}.spm.stats.con.consess{1}.fcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{2}.fcon.name = 'Chinese';
matlabbatch{3}.spm.stats.con.consess{2}.fcon.weights = [0 1];
matlabbatch{3}.spm.stats.con.consess{2}.fcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.delete = 0;


